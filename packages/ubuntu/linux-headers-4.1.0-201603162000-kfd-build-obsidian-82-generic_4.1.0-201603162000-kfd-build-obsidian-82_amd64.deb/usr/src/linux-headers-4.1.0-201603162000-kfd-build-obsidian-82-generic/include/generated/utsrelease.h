#define UTS_RELEASE "4.1.0-201603162000-kfd-build-obsidian-82-generic"
#define UTS_UBUNTU_RELEASE_ABI 82

/* This file is auto generated, version 82 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#82 SMP Wed Mar 16 20:01:20 EDT 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "jenkins-raptor-1"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04.1) "
